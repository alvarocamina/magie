package InsertarDatosMySQL;

public class Menu {
	
	public static void main(String[] args) {
	
	Personas p1 = new Personas("Eder", "Hurtado", "65");
	
	Conector conexion = new Conector();
	
	

}
}
